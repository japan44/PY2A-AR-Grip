Print the grip with the top down using frame print settings, 
the cap should be printed on its side. tool and tool plug should be printed upright
.1mm layer height
100% infill